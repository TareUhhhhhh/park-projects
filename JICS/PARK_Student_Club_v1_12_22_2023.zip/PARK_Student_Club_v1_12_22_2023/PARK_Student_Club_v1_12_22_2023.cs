﻿using System;
using Jenzabar;
using Jenzabar.Common;
using Jenzabar.Common.Globalization;
using Jenzabar.Portal.Framework;
using Jenzabar.Portal.Framework.Configuration;
using Jenzabar.Portal.Framework.Data;
using Jenzabar.Portal.Framework.Web;
using Jenzabar.Portal.Framework.Web.UI;
using Jenzabar.Portal.Framework.Web.UI.Controls;
using Jenzabar.Portal.Framework.Web.UI.Controls.MetaControls;
using Jenzabar.Portal.Framework.Web.UI.Controls.MetaControls.Attributes;
using Jenzabar.Portal.Framework.Preferences;
using Jenzabar.Portal.Framework.Security.Authorization;
using System.Collections.Generic;
using System.Linq;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Text;
using System.Web;

namespace PARK_Student_Club_v1_12_22_2023
{
    public class PARK_Student_Club_v1_12_22_2023 : PortletBase
    {
        protected override PortletViewBase GetCurrentScreen()
        {
            PortletViewBase screen = null;

            switch (this.CurrentPortletScreenName)
            {
                case "Welcome":
                    screen = LoadPortletView("ICS/PARK_Student_Club_v1_12_22_2023/wuc_Welcome.ascx");
                    break;
                default:
                    screen = LoadPortletView("ICS/PARK_Student_Club_v1_12_22_2023/wuc_Welcome.ascx");
                    break;
            }
            //screen = LoadPortletView("ICS/PARK_Faculty_Academic_Tools_v1_1_5_2010/Faculty_Default_View.ascx");

            return screen;
        }

    }
}
